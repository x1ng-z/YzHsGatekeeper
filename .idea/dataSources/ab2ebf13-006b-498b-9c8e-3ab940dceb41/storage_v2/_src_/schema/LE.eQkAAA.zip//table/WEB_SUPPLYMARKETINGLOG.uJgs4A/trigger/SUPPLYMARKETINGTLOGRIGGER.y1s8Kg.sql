create trigger SUPPLYMARKETINGTLOGRIGGER
  before insert or update
  on WEB_SUPPLYMARKETINGLOG
  for each row
  declare
  -- local variables here
begin
		if :new.TITLE='同步提货单' AND :new.requesttype IS NULL  then 
      :new.requesttype:='POST' ;
			:new.url:='/smp/nc-business/addNcTruckLoading';
			end IF;
		if :new.TITLE='卸料过磅' AND :new.requesttype IS NULL then 
      :new.requesttype:='PUT' ;
			:new.url:='/smp/nc-business/callbackPurchaseBill';
			end IF;
end SUPPLYMARKETINGtLOGrigger;
/

