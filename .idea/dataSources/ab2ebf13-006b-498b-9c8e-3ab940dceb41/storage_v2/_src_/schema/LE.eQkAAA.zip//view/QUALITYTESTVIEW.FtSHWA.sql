create view QUALITYTESTVIEW as
  select distinct '' as vdef18, ---客商
       bd_material.name as materialName, --存货名称
       bd_material.graphid as invname, --品牌及品种
       lq.PK_Org,
       cmum.Vcementnumber batchcode, --编号
       bd_material.materialtype vvariety, --强度等级
       substr(lq.facturedate, 1, 10) facdatetime, --出厂日期
        case when lqp28d.pre1 is  null
          then to_char(sysdate,'yyyy-mm-dd')
          else to_char(to_date(substr(lq.facturedate, 1, 10) ,'yyyy-mm-dd')+28 ,'yyyy-mm-dd')
          end  as submitDate,
         --填报日期（没有28天强度时，取当前日期；有时取出厂日期+28天日期）

       --CAST(lqb.mixingamount as numeric(10,1)) free1,--混合材掺量
       lqb.mixingamount free1,--混合材掺量

       --lq.typekiln         typekiln, --生成窑型
       lq.facturenum       allcount, --出厂数量

       --CAST(lq.gypsumcontent as numeric(10,1)) vtestitem34, --石膏掺量
       lq.gypsumcontent vtestitem34, --石膏掺量

       --CAST(lq.grindagentamount as numeric(10,3)) free3, --助磨剂掺量
       lq.grindagentamount free3, --助磨剂掺量

       lq.grindagent       free5, --助磨剂主要成份
       lqb.mixedwood       mixedwood, --混合材品种及成分
       --石灰石
       --CAST(lqbshs.Mixingamount as numeric(10,2)) vstring1,
       lqbshs.Mixingamount vstring1,
       --lqbshs.silica       vstring1, --Si02(%)
       --lqbshs.alumina      vstring2, --A1203(%)
       --lqbshs.ironoxide    vstring3, --Fe203(%)
       --lqbshs.calciumoxide vstring4, --Ca0(%)
       --lqbshs.magnesia     vstring5, --Mgo(%)
       --粉煤灰
       --CAST(lqbfmh.Mixingamount as numeric(10,2)) vstring2,
       lqbfmh.Mixingamount vstring2,
       --lqbfmh.silica       vstring6, --Si02(%)
       --lqbfmh.alumina      vstring7, --A1203(%)
       --lqbfmh.ironoxide    vstring8, --Fe203(%)
       --lqbfmh.calciumoxide vstring9, --Ca0(%)
       --lqbfmh.magnesia     vstring10, --Mgo(%)
       --石煤
       --CAST(lqbsm.Mixingamount as numeric(10,2)) vstring3,
       lqbsm.Mixingamount vstring3,
       --lqbsm.silica       vdouble1, --Si02(%)
       --lqbsm.alumina      vdouble2, --A1203(%)
       --lqbsm.ironoxide    vdouble3, --Fe203(%)
       --lqbsm.calciumoxide vdouble4, --Ca0(%)
       --lqbsm.magnesia     vdouble5, --Mgo(%)
       --粒化高炉矿渣
       --CAST(lqblhglkz.Mixingamount as numeric(10,2)) vstring4,
       lqblhglkz.Mixingamount vstring4,
       --lqblhglkz.silica       vdouble6, --Si02(%)
       --lqblhglkz.alumina      vdouble7, --A1203(%)
       --lqblhglkz.ironoxide    vdouble8, --Fe203(%)
       --lqblhglkz.calciumoxide vdouble9, --Ca0(%)
       -- lqblhglkz.magnesia     vdouble10, --Mgo(%)
       --煤矸石
       --CAST(lqbmgs.Mixingamount as numeric(10,2)) vstring5,
       lqbmgs.Mixingamount vstring5,

       --矿粉
       lqbkf.Mixingamount kfvstring6,

       --选矿粉末
       lqbxkfm.mixingamount xkfmvstring7,

       lq.magnesia vtestitem26, --氧化镁
       lq.trioxide vtestitem27, --三氧化硫

       lq.def4 vsurfacearea, --比表面积

       lq.fineness vfine, --细度
       --CAST(lq.chlorine as numeric(10,3)) vtestitem29, --氯离子
       lq.chlorine vtestitem29, --氯离子
       lq.starttime vcurdtime1, --初凝时间
       lq.endtime vcurdtime2, --终凝时间
       '合格' vstable, --安定性

       lq.def1 srxg, --水溶性6价铬
       lq.def6 brw, --不溶物
       lq.def5 jhl, --碱含量
       lq.c3a  c3a, --c3a
       lq.fcao fcao, --f-cao
       lq.def2 ssl, --烧失量
       lq.def8 bzcd, --标准稠度

       lq.def7 bsl, --保水率
       lq.ir ir, --Ir
       lq.ira ira,--IRa

       --3天抗压强度
       /*CAST(lqp3d.pre1 as numeric(10,1)) vtestitem7,
       CAST(lqp3d.pre2 as numeric(10,1)) vtestitem8,
       CAST(lqp3d.pre3 as numeric(10,1)) vtestitem9,
       CAST(lqp3d.pre4 as numeric(10,1)) vtestitem16,
       CAST(lqp3d.pre5 as numeric(10,1)) vtestitem17,
       CAST(lqp3d.pre6 as numeric(10,1)) vtestitem18,*/
       lqp3d.pre1 vtestitem7,
       lqp3d.pre2 vtestitem8,
       lqp3d.pre3 vtestitem9,
       lqp3d.pre4 vtestitem16,
       lqp3d.pre5 vtestitem17,
       lqp3d.pre6 vtestitem18,
       NVL('X=' || to_char(lqp3d.avgpre), '待报') as vtrength3,
       --(nvl(lqp3d.pre1,0)+nvl(lqp3d.pre2,0)+nvl(lqp3d.pre3,0)+nvl(lqp3d.pre4,0)+nvl(lqp3d.pre5,0)+nvl(lqp3d.pre6,0))/6 vtrength3,
       --28天抗压强度
       /*CAST(lqp28d.pre1 as numeric(10,1)) vtestitem10,
       CAST(lqp28d.pre2 as numeric(10,1)) vtestitem11,
       CAST(lqp28d.pre3 as numeric(10,1)) vtestitem12,
       CAST(lqp28d.pre4 as numeric(10,1)) vtestitem19,
       CAST(lqp28d.pre5 as numeric(10,1)) vtestitem20,
       CAST(lqp28d.pre6 as numeric(10,1)) vtestitem21,*/
       lqp28d.pre1 vtestitem10,
       lqp28d.pre2 vtestitem11,
       lqp28d.pre3 vtestitem12,
       lqp28d.pre4 vtestitem19,
       lqp28d.pre5 vtestitem20,
       lqp28d.pre6 vtestitem21,
       NVL('X=' || to_char(lqp28d.avgpre), '待报') as vtrength4,
       --(nvl(lqp28d.pre1,0)+nvl(lqp28d.pre2,0)+nvl(lqp28d.pre3,0)+nvl(lqp28d.pre4,0)+nvl(lqp28d.pre5,0)+nvl(lqp28d.pre6,0))/6 vtrength4,
       --3天抗折强度
       /*CAST(lqf3d.fold1 as numeric(10,1)) vtestitem1,
       CAST(lqf3d.fold2 as numeric(10,1)) vtestitem2,
       CAST(lqf3d.fold3 as numeric(10,1)) vtestitem3,*/
       lqf3d.fold1 vtestitem1,
       lqf3d.fold2 vtestitem2,
       lqf3d.fold3 vtestitem3,
       NVL('X=' || to_char(lqf3d.avgfold), '待报') as vtrength1,
       --(nvl(lqf3d.fold1,0)+nvl(lqf3d.fold2,0)+nvl(lqf3d.fold3,0))/3 vtrength1,
       --28天抗折强度
       /*CAST(lqf28d.fold1 as numeric(10,1)) vtestitem4,
       CAST(lqf28d.fold2 as numeric(10,1)) vtestitem5,
       CAST(lqf28d.fold3 as numeric(10,1)) vtestitem6,*/
       lqf28d.fold1 vtestitem4,
       lqf28d.fold2 vtestitem5,
       lqf28d.fold3 vtestitem6,
       NVL('X=' || to_char(lqf28d.avgfold), '待报') as vtrength2
--(nvl(lqf28d.fold1,0)+nvl(lqf28d.fold2,0)+nvl(lqf28d.fold3,0))/3 vtrength2
  from levm_qualityinspection lq
  left join levm_qualityinspection_b lqb
    on lq.pk_qualityinspection = lqb.id_quality_b
  left join lepbd_cementnumber cmum
    on cmum.pk_cementnumber = lq.vcementnumber /* 水泥编号 */
  left join bd_material
    on lq.def3 = pk_material
--石灰石
  left join levm_qualityinspection_b lqbshs
    on lq.pk_qualityinspection = lqbshs.id_quality_b
   and lqbshs.mixedwood in (select b.pk_defdoc
                              from bd_defdoclist bl
                              left join bd_defdoc b
                                on bl.pk_defdoclist = b.pk_defdoclist
                             where bl.code = 'hhc'
                               and nvl(b.dr, 0) = 0
                               and nvl(bl.dr, 0) = 0
                               and b.code = '18120701')
--粉煤灰
  left join levm_qualityinspection_b lqbfmh
    on lq.pk_qualityinspection = lqbfmh.id_quality_b
   and lqbfmh.mixedwood in (select b.pk_defdoc
                              from bd_defdoclist bl
                              left join bd_defdoc b
                                on bl.pk_defdoclist = b.pk_defdoclist
                             where bl.code = 'hhc'
                               and nvl(b.dr, 0) = 0
                               and nvl(bl.dr, 0) = 0
                               and b.code = '18120702')
--石煤
  left join levm_qualityinspection_b lqbsm
    on lq.pk_qualityinspection = lqbsm.id_quality_b
   and lqbsm.mixedwood in (select b.pk_defdoc
                             from bd_defdoclist bl
                             left join bd_defdoc b
                               on bl.pk_defdoclist = b.pk_defdoclist
                            where bl.code = 'hhc'
                              and nvl(b.dr, 0) = 0
                              and nvl(bl.dr, 0) = 0
                              and b.code = '18120703')
--粒化高炉矿渣
  left join levm_qualityinspection_b lqblhglkz
    on lq.pk_qualityinspection = lqblhglkz.id_quality_b
   and lqblhglkz.mixedwood in
       (select b.pk_defdoc
          from bd_defdoclist bl
          left join bd_defdoc b
            on bl.pk_defdoclist = b.pk_defdoclist
         where bl.code = 'hhc'
           and nvl(b.dr, 0) = 0
           and nvl(bl.dr, 0) = 0
           and b.code = '18120704')
--煤矸石
  left join levm_qualityinspection_b lqbmgs
    on lq.pk_qualityinspection = lqbmgs.id_quality_b
   and lqbmgs.mixedwood in (select b.pk_defdoc
                              from bd_defdoclist bl
                              left join bd_defdoc b
                                on bl.pk_defdoclist = b.pk_defdoclist
                             where bl.code = 'hhc'
                               and nvl(b.dr, 0) = 0
                               and nvl(bl.dr, 0) = 0
                               and b.code = '19010101')
--矿粉
  left join levm_qualityinspection_b lqbkf
    on lq.pk_qualityinspection = lqbkf.id_quality_b
   and lqbkf.mixedwood in (select b.pk_defdoc
                              from bd_defdoclist bl
                              left join bd_defdoc b
                                on bl.pk_defdoclist = b.pk_defdoclist
                             where bl.code = 'hhc'
                               and nvl(b.dr, 0) = 0
                               and nvl(bl.dr, 0) = 0
                               and b.code = '19010102')
--选矿粉末
  left join levm_qualityinspection_b lqbxkfm
    on lq.pk_qualityinspection = lqbxkfm.id_quality_b
   and lqbxkfm.mixedwood in (select b.pk_defdoc
                              from bd_defdoclist bl
                              left join bd_defdoc b
                                on bl.pk_defdoclist = b.pk_defdoclist
                             where bl.code = 'hhc'
                               and nvl(b.dr, 0) = 0
                               and nvl(bl.dr, 0) = 0
                               and b.code = '19010103')
--抗折3天
  left join levm_qualityinspection_f lqf3d
    on lq.pk_qualityinspection = lqf3d.id_quality_f
   and lqf3d.fold = 1
--抗折28天
  left join levm_qualityinspection_f lqf28d
    on lq.pk_qualityinspection = lqf28d.id_quality_f
   and lqf28d.fold = 3
--抗压3天
  left join levm_qualityinspection_p lqp3d
    on lq.pk_qualityinspection = lqp3d.id_quality_p
   and lqp3d.pressure = 1
--抗压28天
  left join levm_qualityinspection_p lqp28d
    on lq.pk_qualityinspection = lqp28d.id_quality_p
   and lqp28d.pressure = 3
/

