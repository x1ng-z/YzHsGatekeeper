create view VDT_OPERATIONLOG as
  SELECT     olog.Id, olog.LogId, olog.CPNum, olog.ChannelNo, olog.Type, olog.Material, olog.Client, olog.CarNo, olog.YZL, olog.Bags, olog.CIJ, olog.ICCard, olog.RecordID,
                      olog.StartTime, olog.EndTime, olog.Note, olog.CreateDate, olog.Memo, olog.OL1, olog.OL2, olog.OL3, olog.OL4, olog.OL5, olog.OL6, olog.OL7, olog.OL8, olog.OL9,
                      olog.OL10, sc.ChannelName
FROM         DT_OperationLog  olog
LEFT OUTER JOIN
                      DT_SiloChannel  sc ON olog.ChannelNo = sc.ChannelNo
/

