create view VIEW_NAME as
  select  pk_org type from org_orgs
/

