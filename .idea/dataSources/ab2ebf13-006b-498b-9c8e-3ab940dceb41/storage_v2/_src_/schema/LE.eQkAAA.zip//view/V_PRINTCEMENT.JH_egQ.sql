create view V_PRINTCEMENT as
  select lm.vbillcode as OrderNO,
       h.vvehicle as carname,
       h.dbizdate,
       b.pk_customer as customerID, /*客户ID*/
       bc.name AS customername, /*客户名称*/
       bm.name AS materialname, /*等级强度*/
       lcn.vcementnumber AS ReservationListName4, /*批号*/
       aa.name AS ReservationListName5,     /**库号**/
       def.pk_defdoc as Proline, /* 生产线ID */
       def.name AS ReservationList1, /*生产线名称*/
       h.nnet AS Suttle, /*净重*/
       h.nnet AS DX, /*净重*/
       h.Ngross as Gross, /*毛重*/
       h.Ntare as Tare, /*皮重**/
       h.Ngross as NGross, /*毛重*/
       h.Ntare as NTare, /*皮重**/

       h.vbillcode AS billNo, /*NC磅单号*/
       '' as carID, /*车号ID */
       h.dgrosstime AS GrossTime, /* 过毛重时间*/
       h.dtaretime AS TareTime, /* 过皮重时间*/
       b.cmaterialoid AS MaterialID, /* 物料ID*/
       h.vvehicle AS carsname, /*车号*/
       EP.WBBILLNO AS IsPrint,    /*一卡通磅单号*/
       b.pk_sourcebill as wbBillNo,  /*  销售订单ID */
       h.pk_poundbill, /*NC磅单号主键*/
       b.nplannum AS yfsuttle, /*提货数量*/
       bb.name as GRAPHID, /*水泥品牌**/
       h.vbillcode as NCBillNO,
       substr(h.vdef5,1,10) as TJRQ, /*统计日期*/
       replace(lm.vdef12 ,'~','') as vnote, /*提货单号（取值规则：length(h_vnote)>19?mid(h_vnote , 12,20 ) :h_vnote）***/
       replace(areaf.vdef18,'~','') as memo, /* 大区编号 */
        case when h.Ctrantypeid  in ('1001G110000000000140','1001G11000000000KENV') then '散装'
        when h.Ctrantypeid in ('1001G11000000000015G','1001G11000000000HM9V') then '袋装'
       end as ctype,
       '' as ptype,
       h.Ctrantypeid,   /*  计量类型  */
       b.pk_sourcebill as OrderID,  /*  销售订单ID */
       b.vorigsrcbillcode as OrderCode, /*  销售订单编号 */
      lm.vbillcode as ContractBillNo,
     eam.status as OrderStatus /* 信用验证情况 */
  from levm_poundbill h
  inner join levm_poundbill_b b  on h.pk_poundbill = b.pk_poundbill
  left join bd_customer bc    on b.pk_customer = bc.pk_customer
  left join  bd_custsale on bc.pk_customer =bd_custsale. pk_customer and bd_custsale.pk_Org ='0001G110000000002ZU7'  /* 客户子表 限定厂区，各厂分别修改  */
  left join levm_meambill areaf on b.pk_sourcebill = areaf.PK_MEAMAPPLY and  areaf.VBILLCODETYPE in('4EBP','4EBC')  -- 销售订单，关联地区编号
  left join bd_material bm    on b.cmaterialoid = bm.pk_material
  left join bd_branddoc bb    on bm.pk_brand = bb.pk_brand
  left join lepbd_cementnumber lcn    on lcn.pk_cementnumber = b.pk_cementnumber
  left join Lepbd_WareHouseDoc aa ON aa.pk_WareHouseDoc = lcn.vdef6     /* 库号 */
  left join bd_defdoc def   ON def.pk_defdoc = b.vbdef10  /*  生产线 */
  left join EAM_PrintLog EP on EP.WBBILLNO = h.vbillcode
  left join levm_meambill lm on lm.pk_meamapply = b.pk_sourcebill  /* 销售订单 */
  left join EAM_CheckCredit eam on eam.OrderID = b.pk_sourcebill and eam.status = '1'
 where nvl(h.dr, 0) = 0 and h.nbillstatus = '2'  /* 磅单状态 1-未完成 2-完成 3-修改待审 4-  5-  */
   and h.Ctrantypeid  in ('1001G110000000000140','1001G11000000000HM9V','1001G11000000000KENV','1001G11000000000015G')
   and nvl(b.dr, 0) = 0
/

