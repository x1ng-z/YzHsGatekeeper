create view V_PRINTPOUND as
  SELECT ROWNUM as "rownum",
    A .vvehicle AS carName,
    A .nnet AS suttle,
    lcn.vcementnumber AS ph,
    bm.name AS materialName,
    substr(A.vdef5,1,10) AS tjrq,
    CASE WHEN nbillstatus = '2' THEN '已过磅' ELSE '未过磅' END AS flag,
    CASE WHEN NVL (lqip.pre6, '0') = '0' THEN 0 ELSE 1 END title,
    CASE WHEN NVL (lqip.pre6, '0')  = '0' AND EOS_PRINT_LOG.PRINTTYPE IS NULL THEN '普通打印'
      WHEN NVL (lqip.pre6, '0') = '0' AND  EOS_PRINT_LOG.PRINTTYPE = '0' THEN '已打印'
      WHEN NVL (lqip.pre6, '0') > '0' AND  EOS_PRINT_LOG.PRINTTYPE = '0' THEN '普通打印'
      WHEN NVL (lqip.pre6, '0') > '0' AND  EOS_PRINT_LOG.PRINTTYPE = '1' THEN '已打印' END buttonTile,
    CASE WHEN NVL (lqip.pre6, '0')  = '0' AND EOS_PRINT_LOG.PRINTTYPE IS NULL THEN '高铁打印'
      WHEN NVL (lqip.pre6, '0') = '0' AND  EOS_PRINT_LOG.PRINTTYPE = '0' THEN '已打印'
    WHEN NVL (lqip.pre6, '0') > '0' AND    EOS_PRINT_LOG.PRINTTYPE = '0' THEN '高铁打印'
    WHEN NVL (lqip.pre6, '0') > '0' AND    EOS_PRINT_LOG.PRINTTYPE = '1' THEN '已打印' END buttonTileGT,
    A .pk_poundbill AS billno,
    'P' AS  RESOURCETYPE
FROM levm_poundbill A
LEFT JOIN levm_poundbill_b b ON A .PK_POUNDBILL = b.PK_POUNDBILL
INNER JOIN bd_material bm ON b.cmaterialoid =  bm.pk_material
left join lepbd_cementnumber lcn
    on lcn.pk_cementnumber = b.pk_cementnumber
left join levm_qualityinspection lqi
    on lqi.vcementnumber = lcn.pk_cementnumber
left join levm_qualityinspection_p lqip
    on lqi.pk_qualityinspection = lqip.id_quality_p
   and lqip.pressure = '3'
LEFT JOIN EOS_PRINT_LOG ON CASE WHEN EOS_PRINT_LOG.RESOURCETYPE = 'S' AND
      EOS_PRINT_LOG.RESOURCEID = B .pk_sourcebill THEN 1
      WHEN EOS_PRINT_LOG.RESOURCETYPE = 'P' AND
      EOS_PRINT_LOG.RESOURCEID = A .pk_poundbill THEN 1 ELSE 0 END = 1
WHERE A.dr = 0
 and A.Ctrantypeid in ('1001G110000000000140','1001G11000000000HM9V','1001G11000000000KENV','1001G11000000000015G')
/

