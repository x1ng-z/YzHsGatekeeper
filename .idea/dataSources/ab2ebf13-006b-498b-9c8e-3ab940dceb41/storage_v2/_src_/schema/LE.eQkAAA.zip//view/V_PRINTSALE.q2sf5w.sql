create view V_PRINTSALE as
  select ROWNUM as "rownum",
       ldb.vvehicle AS carName, /* 车号 */
       ldbb.nnum AS suttle,    /* 净重 */
       lcn.vcementnumber AS ph,   /* 水泥编号 */
       bm.name AS materialName,  /* 物料名称 */
       ldb.dbilldate AS tjrq,    /* 统计日期 */
       '未过磅' AS flag,
       CASE
         WHEN NVL(lqip.pre6, '0') = '0' THEN 0
         ELSE 1
       END title,
       CASE
         WHEN NVL(lqip.pre6, '0') = '0' AND /* 28天抗压6 */   EPL.PRINTTYPE IS NULL THEN '普通打印'
         WHEN NVL(lqip.pre6, '0') = '0' AND EPL.PRINTTYPE = '0' THEN  '已打印'
         WHEN NVL(lqip.pre6, '0') > '0' AND EPL.PRINTTYPE = '0' THEN  '普通打印'
         WHEN NVL(lqip.pre6, '0') > '0' AND EPL.PRINTTYPE = '1' THEN  '已打印'
       END buttonTile,
       CASE
         WHEN NVL(lqip.pre6, '0') = '0' AND EPL.PRINTTYPE IS NULL THEN '高铁打印'
         WHEN NVL(lqip.pre6, '0') = '0' AND EPL.PRINTTYPE = '0' THEN '已打印'
         WHEN NVL(lqip.pre6, '0') > '0' AND EPL.PRINTTYPE = '0' THEN '高铁打印'
         WHEN NVL(lqip.pre6, '0') > '0' AND EPL.PRINTTYPE = '1' THEN '已打印'
       END buttonTileGT,
       ldbb.pk_meamapply AS billno, /* 单据主键 */
       'S' AS RESOURCETYPE
  from levm_deliverybill ldb
  left join levm_deliverybill_b ldbb
    on ldb.pk_delivery = ldbb.pk_delivery
  left join lepbd_cementnumber lcn
    on lcn.pk_cementnumber = ldbb.pk_cementnumber
  left join bd_material bm
    on bm.pk_material = ldbb.pk_material
  left join levm_qualityinspection lqi
    on lqi.vcementnumber = lcn.pk_cementnumber
  left join levm_qualityinspection_p lqip
    on lqi.pk_qualityinspection = lqip.id_quality_p
   and lqip.pressure = '3'
  left join EOS_PRINT_LOG EPL
    on EPL.RESOURCETYPE = 'S'
   and EPL.RESOURCEID = ldbb.pk_meamapply
 WHERE ldb.dr = '0'
  and ldb.fstatusflag = '1'   /* 单据状态：0—>已计量   -1—>未计量   1—>作废  */
  and ldb.vbilltype = '0001Y0100000000009BY'
   AND nvl(ldb.dr,0) = 0
   AND nvl(ldbb.dr,0)= 0
   and    ldb.bisreviseflag LIKE (case
         when instr(bm.name, '散') > 0 then  ('%%')
         else ('N')
       end)
   and  ldb.dbilldate >=to_char(sysdate-1,'yyyy-mm-dd')
   and ldb.dbilldate < to_char(sysdate+1,'yyyy-mm-dd')
/

