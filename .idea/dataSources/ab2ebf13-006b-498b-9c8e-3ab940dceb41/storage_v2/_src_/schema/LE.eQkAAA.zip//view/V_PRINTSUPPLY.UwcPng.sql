create view V_PRINTSUPPLY as
  select DISTINCT ROWNUM as "rowNum",lpb.TS,
lpb.dbizdate,/* 日期 */
substr(lpb.vdef5,1,10) as TJRQ,/* 统计日期 */
lpb.pk_poundbill ,  /* 主键 */
bs.pk_supplier as supplyID,  /* 发货单位ID */
lpbb.cbiztypeid,
case
when lpb.Ctrantypeid in ('1001G110000000000135') then '2'
  when lpb.Ctrantypeid in ('1001G11000000000VZFG') then '3'
  when lpb.Ctrantypeid in ('1001G11000000000S1L3','1001G4100000000073I7') then '4'
  when lpb.Ctrantypeid in ('1001G11000000000VZE8') then '5'
  end as ModuleType,     /* 业务流程 1-销售 2-采购 3-倒料 4-其它计量 5-矿山 */
--'" + rc6 + "' as supplyname, /* 调拨 */
bs.name as supplyname,/* 非调拨 */
'' as carID,  /* 车辆ID */
lpb.vvehicle as carsname,/*车牌号*/
bm.pk_material as MaterialID,
bm.name as materialname,
lpb.ngross as gross,lpb.ntare as tare,lpb.nnet as Suttle, --毛重、皮重、净重
NVL(lpbb.vbdef4, 0) AS nabatenum, --扣重
bdscx.pk_defdoc AS Proline,  /* 生产线ID */
bdscx.name AS scx,  /* 生产线 */
bdkd.pk_defdoc, /* 采购矿点ID */
lpb.ctrantypeid, /* 类型ID */
--'" + rc7 + "' as cgkd, /*调拨采购矿点 */
bdkd.name AS cgkd, /*非调拨采购矿点 */
replace(vbdef8,'~',0) as supplierSuttle, /* 供方净重 */
replace(vbdef8,'~',0) as YFSuttle,
case when replace(vbdef8,'~',0)>0 then '合格' else '不合格' end as HandSuttle, /* 供方净重合格名称  合格或不合格*/
lpb.vbillcode as billNo,  /* 磅单号*/
'' as ReservationChar5,
'" + rc6 + "' as ReservationListName1,  /* 线别名称 */
'' as ReservationCharName3,
lpb.dtaretime as LightDate,  /* 皮重时间*/
lpb.dtaretime as TareTime,  /* 皮重时间*/
lpb.dgrosstime as GrossTime,  /* 毛重时间*/
'' as wbBillNo, --一卡通单据号，65没有一卡通
lpb.vnote,
case WHEN EP.WBBillNo IS NOT NULL THEN(
select count(1) from EAM_PrintLog T
where T .WBBillNo = EP.WBBillNo )
else 0 end printCount --一卡通单据号没了如何处理打印次数？
from levm_poundbill lpb
left join levm_poundbill_b lpbb on lpb.pk_poundbill = lpbb.pk_poundbill
left join bd_supplier bs on lpbb.pk_supplier = bs.pk_supplier
left join bd_material bm on lpbb.cmaterialoid = bm.pk_material
left join bd_defdoc  bdscx on bdscx.pk_defdoc = lpbb.vbdef10
left join bd_defdoc bdkd on bdkd.pk_defdoc = lpbb.vbdef3
left join EAM_PrintLog EP on EP.WBBILLNO = lpb.vbillcode
where nvl(lpb.dr,0) = 0  and lpb.nbillstatus = '2'  /* 磅单状态 1-未完成 2-完成 3-修改待审 4-  5-  */
    and nvl(lpbb.dr,0) = 0
    and substr(lpb.vdef5,1,10) >=to_char(add_months(sysdate ,-3),'yyyy-mm-dd')
    and substr(lpb.vdef5,1,10) >='2016-08-01'
    and EP.Wbbillno is null
    and lpb.Ctrantypeid not in ('1001G110000000000140','1001G11000000000HM9V','1001G11000000000KENV','1001G11000000000015G')
ORDER BY substr(lpb.vdef5,1,10) DESC
/

