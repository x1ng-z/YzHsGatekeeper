create view V_SALECARD as
  select A.vehicle as CarName,
A.vcardid as cardid
,A.fstatusflag as CardStatus  /*卡片状态  0-已注册 1-已发放 2-已冻结 3-已作废  */
from levm_cardmanage A
WHERE A.dr = '0'
/

