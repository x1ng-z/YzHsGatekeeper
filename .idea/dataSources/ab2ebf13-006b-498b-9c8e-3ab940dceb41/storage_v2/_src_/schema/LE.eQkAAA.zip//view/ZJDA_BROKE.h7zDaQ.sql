create view ZJDA_BROKE as
  SELECT fold1,
    fold2,
    fold3,
    fold4,
    fold5,
    fold6,substr(ts,0,10) tss,
    ID_QUALITY_F,fold,avgfold
  FROM levm_qualityinspection_f
  WHERE nvl(dr,0)=0 and fold=3
/

