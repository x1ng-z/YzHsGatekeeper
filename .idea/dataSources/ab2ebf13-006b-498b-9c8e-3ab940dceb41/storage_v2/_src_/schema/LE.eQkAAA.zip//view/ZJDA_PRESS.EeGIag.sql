create view ZJDA_PRESS as
  SELECT pre1,
    pre2,
    pre3,
    pre4,
    pre5,
    pre6,
    ID_QUALITY_p,PRESSURE,AVGPRE
  FROM levm_qualityinspection_p
  WHERE nvl(dr,0)=0 and PRESSURE=3
/

