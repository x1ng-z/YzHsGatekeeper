create view ZJDA_PRINTOUT as
  SELECT defdoc.name,
    mixingamount,
    qb.ID_QUALITY_B,
    row_number()over(partition BY ID_QUALITY_B order by ID_QUALITY_B) rn
  FROM levm_qualityinspection_b qb
  LEFT JOIN bd_defdoc defdoc
  ON qb.mixedwood   =defdoc.pk_defdoc
  WHERE NVL(qb.dr,0)=0
  AND defdoc.dr     =0
/

